public interface Stack
{
    boolean isEmpty();
    void push(Object obj);
    Object pop();
    Object peekTop();
}

