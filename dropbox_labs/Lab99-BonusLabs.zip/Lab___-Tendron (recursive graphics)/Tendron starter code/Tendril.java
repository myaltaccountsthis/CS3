import java.awt.Graphics;
import java.awt.Color;

public class Tendril 
{
	private Graphics g;
	
	public Tendril(Graphics g)
	{
		this.g = g;
	}
}
