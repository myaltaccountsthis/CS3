import java.awt.Graphics;

public class Cluster 
{
	private Graphics g;
	
	public Cluster(Graphics g)
	{
		this.g = g;
	}
	
	public void display(int length, int x, int y)
	{
		//TODO
	}
}
