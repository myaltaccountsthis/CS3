import java.awt.Font;

enum GemType {
    GREEN, BLUE, ORANGE; //define the different types of Gems, comma delimited
}

public class Gem 
{	
	/** Tester main method */
	public static void main(String [] args)
	{
//		final int maxGems = 16;
//		
//		// Create a gem of each type
//		Gem green  = new Gem(GemType.GREEN, 10);
//		Gem blue   = new Gem(GemType.BLUE, 20);
//		Gem orange = new Gem(GemType.ORANGE, 30);
//		System.out.println(green  + ", " + green.getType()  + ", " + green.getPoints());		
//		System.out.println(blue   + ", " + blue.getType()   + ", " + blue.getPoints());
//		System.out.println(orange + ", " + orange.getType() + ", " + orange.getPoints());
//		green.draw(0.3, 0.7);
//		blue.draw(0.5, 0.7);
//		orange.draw(0.7, 0.7);
//		
//		// A row of random gems
//		for (int i = 0; i < maxGems; i++)
//		{
//			Gem g = new Gem();
//			g.draw(1.0 / maxGems * (i + 0.5), 0.5);
//		}
	}
}
