Used as a review of linked lists AFTER the recursive graphics lab.

Skip this lab if you're working ahead!